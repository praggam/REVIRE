﻿using Assets.Scripts.Gameplay;
using UnityEngine;

// Responsible for all logic related to Task 1 in which user must perform combination of movement with both hands to reach out to grab a bottle and pour liquid into a glass. Current implementation allows user to grab bottle and glass with preffered hand. A point is added for every fully filled glass. Pouring while holding both bottle and glass increases the amount of points per full glass x2.
 
/* Difficuly affects:
 *  - glass size
 *  - glass and bottle position on the table
 */
public class Task1 : MonoBehaviour
{
    #region DIFFICULTY SETUP
    private readonly Vector3[] glassSizes = {
        new Vector3(4f, 4f, 6f),
        new Vector3(3f, 3f, 5f),
        new Vector3(2.5f, 2.5f, 4.5f)};
    #endregion

    [Tooltip("Game Object containing the Task class with loadable resources for current task.")]
    [SerializeField] Task task = null;

    [SerializeField] Container bottle = null;
    [SerializeField] Container glass = null;

    [Tooltip("Table boundaries used to determine correct position of grabbables on the table in respect to arms reach calibration and difficulty settings.")]
    [SerializeField] Collider tableCollider = null;

    private Grabbable glassGrabbable = null;

    private void Awake()
    {
        ResizeGrabbables();
        PositionGrabbables();

        if(glass)
        {
            glassGrabbable = glass.GetComponent<Grabbable>();
        }
    }

    private void Start()
    {
        glass.ContainerFull += OnGlassFull;
    }

    private void OnGlassFull()
    {
        // check if user holding glass while pouring. If yes, increase points x2
        int points = 1;
        if (glassGrabbable.IsHeld) { points *= 2; }
            
        ScoreManager.Instance.IncreaseScore(task, points);
    }

    // set glass size according to difficulty level chosen
    private void ResizeGrabbables()
    {
        if (task.Settings.difficulty < 0 || (int) task.Settings.difficulty > glassSizes.Length)
            task.Settings.difficulty = 0;

        glass.transform.localScale =  glassSizes[(int) task.Settings.difficulty];
    }

    // position objects at user's max reach. Depends on difficulty level set and calibration settings
    private void PositionGrabbables()
    {
        float forwardPos = SettingsManager.Instance.Settings.maxReachForward;
        float tableSpace = tableCollider.bounds.max.x - forwardPos;

        if (task.Settings.difficulty == Difficulty.Easy)
        {
            forwardPos += tableSpace * 0.4f;
        }
        else if (task.Settings.difficulty == Difficulty.Normal)
        {
            forwardPos += tableSpace * 0.2f;
        }

        //  make sure it is within table boundary and if not, apply default values
        if (forwardPos > tableCollider.bounds.min.x && forwardPos < tableCollider.bounds.max.x)
        {
            ChangeInitialPosition(glass, forwardPos);

            // TODO fix bottle's pivot, must be remodeled in Blender. Temporarily fixed by adding offset.
            ChangeInitialPosition(bottle, forwardPos - 0.3f);
        }
        else
        {
            Debug.LogWarning("Task 1: Max reach forward outside of table boundary. Retreating to default values.");
        }
    }

    private void ChangeInitialPosition(Container container, float forwardPosition)
    {
        Vector3 newPosition = new Vector3(forwardPosition, container.transform.position.y, container.transform.position.z);

        container.transform.position = newPosition;

        Grabbable grabbable = container.gameObject.GetComponent<Grabbable>();

        if (grabbable)
        {
            grabbable.InitialPosition = newPosition;
        }
    }
}