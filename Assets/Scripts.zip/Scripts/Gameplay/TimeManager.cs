﻿using System;
using System.Collections;
using TMPro;
using UnityEngine;

// Responsible for all time related events such as starting and ending task timer and updating timer display in session. Timer must be initialized by external class to start counting for current task. Triggers event when task time is completed unless stopped earlier which can happen if user ends task prematurely.
public class TimeManager : Singleton<TimeManager>
{
    [SerializeField] TMP_Text timerDisplay = null;

    [Tooltip("Time measured for current task from initialization.")]
    private int currentTaskTime = 0;

    private Coroutine taskTimer = null;
    public event Action<int> TaskTimeEnded;

    private void Awake()
    {
        InitializeSingleton(this);
    }

    public void StartTaskTimer(int taskTime)
    {
        currentTaskTime = 0;
        timerDisplay.text = ConverterUtil.MinutesSecondsToString(taskTime);
        taskTimer = StartCoroutine(TaskTimer(taskTime));
    }

    // returns the task duration
    public int StopTaskTimer()
    {
        if (taskTimer != null)
        {
            StopCoroutine(taskTimer);
        }

        return currentTaskTime;
    }

    private IEnumerator TaskTimer(int taskTime)
    {
        while (currentTaskTime < taskTime)
        {
            yield return new WaitForSeconds(1);
            currentTaskTime += 1;
            timerDisplay.text = ConverterUtil.MinutesSecondsToString(taskTime - currentTaskTime);
        }

        // trigger time ended event to stop the task
        TaskTimeEnded?.Invoke(currentTaskTime);
    }
}