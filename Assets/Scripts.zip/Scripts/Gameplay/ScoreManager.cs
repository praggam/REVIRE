﻿using Assets.Scripts.Gameplay;
using TMPro;
using UnityEngine;

// Responsible for keeping track of session score in permanent storage and updating score display in session. 
public class ScoreManager : Singleton<ScoreManager>
{
    [SerializeField] TMP_Text scoreDisplay = null;

    private void Awake()
    {
        InitializeSingleton(this);
        UpdateScoreDisplay(0);

        GameManager.OnTaskStarted += OnScoreUpdate;
    }

    private void OnScoreUpdate(Task task)
    {
        UpdateScoreDisplay(task.Settings.currentScore);
    }

    public void ResetScore(Task task)
    {
        task.Settings.currentScore = 0;
    }

    public void ResetSessionScore()
    {
        foreach (Task t in GameManager.Instance.Tasks)
        {
            ResetScore(t);
        }
    }

    public void IncreaseScore(Task task, int score)
    {
        task.Settings.currentScore += score;

        if (task.Equals(GameManager.Instance.CurrentTask))
        {
            UpdateScoreDisplay(task.Settings.currentScore);
        }
    }

    public void UpdateScoreDisplay(int score)
    {
        scoreDisplay.text = ConverterUtil.PointsToString(score);

    }
}