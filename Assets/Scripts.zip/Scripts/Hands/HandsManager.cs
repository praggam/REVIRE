﻿using UnityEngine;

public class HandsManager : Singleton<HandsManager>
{
    [SerializeField]
    private OVRHand handLeft = null;

    [SerializeField]
    private OVRHand handRight = null;

    [Tooltip("Enable to allow kinematic grabbing of objects by right/left hand.")]
    public bool kinematicGrabbing = true;

    [Tooltip("Enable to allow both-handed grabbing of objects. Note that it is not recommended to use both-handed grabbing with kinematic grabber at the same time.")]
    public bool bothHandedGrabbing = false;

    public bool BothHandsTracked => IsHandActive(handLeft) && IsHandActive(handRight);
    public bool LeftHandActive => IsHandActive(handLeft);
    public bool RightHandActive => IsHandActive(handRight);

    public OVRHand HandLeft { get => handLeft; set => handLeft = value; }
    public OVRHand HandRight { get => handRight; set => handRight = value; }

    private void Awake()
    {
        InitializeSingleton(this);
    }

    public void ResetGrabbables()
    {
        // reset active streams
        StreamBehaviour[] streams = FindObjectsOfType<StreamBehaviour>();
        foreach (StreamBehaviour s in streams)
        {
            Destroy(s.gameObject);
        }

        // reset positions
        Grabbable[] grabbables = FindObjectsOfType<Grabbable>();
        for (int i = 0; i < grabbables.Length; ++i)
        {
            grabbables[i].ResetPosition();
        }
    }

    private bool IsHandActive(OVRHand hand)
    {
        return 
            hand != null &&
            hand.IsTracked &&
            hand.HandConfidence.Equals(OVRHand.TrackingConfidence.High);
    }
}