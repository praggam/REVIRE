﻿public enum HandPose
{
    Default = -1,
    Open = 0,
    Fist = 1,
    ThumbsUp = 2,
    CountTwo = 3,
    CountThree = 4,
    Victory = 5
}
