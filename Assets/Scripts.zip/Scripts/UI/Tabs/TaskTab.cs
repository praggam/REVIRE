﻿using Assets.Scripts.Gameplay;
using UnityEngine;

public class TaskTab : MonoBehaviour
{
    public TaskType task;
}
