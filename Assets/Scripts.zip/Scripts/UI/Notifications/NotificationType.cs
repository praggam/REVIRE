﻿public enum NotificationType
{
    DefaultNotification,
    HandsNotification
}
