﻿public enum HandState
{
    DEFAULT = -1,
    EMPTY = 0,
    GRABBING = 1
}
