﻿using Assets.Scripts.Gameplay;
using System;
using System.Collections.Generic;
using UnityEngine;
using LSL;
using System.Threading;

public class LSLSender
{
    public static void SendLslForTask(float[] data)
    {

        // create stream info and outlet
        StreamInfo info = new StreamInfo("TaskStart", "EEG", 1, 100, LSL.channel_format_t.cf_float32, "VR");
        StreamOutlet outlet = new StreamOutlet(info);
        outlet.push_sample(data);

    }



    public static float[] Data = {-1};

    public static void SendLslForTask()
    {

        // create stream info and outlet
        StreamInfo info = new StreamInfo("TaskStart", "EEG", 1, 100, LSL.channel_format_t.cf_float32, "VR");
        StreamOutlet outlet = new StreamOutlet(info);
        outlet.push_sample(Data);

    }
}