﻿using Assets.Scripts.Gameplay;
using System.Collections;
using TMPro;
using UnityEngine;

// Responsible for all logic related to Task 2 in which user simulates drinking from glass or bottle. Drinking from glass is activated when glass is placed within a defined range of user's mouth as tracked by the HMD (through eye level tracking). Drinking from bottle adds an additional difficulty aspect as bottle must be tilted above user's eye level. The tilt angle depends on the leevl of liquid in the bottle. 

/* Difficuly affects:
 *  - glass size
 *  - glass and bottle position on the table
 *  - bottle minimum capacity - bottle gets filled up more often to adjust to smaller/larger tilting angle requirement
 */
public class Task2 : MonoBehaviour
{
    #region DIFFICULTY SETUP
    private readonly Vector3[] glassSizes = {
        new Vector3(4f, 4f, 6f),
        new Vector3(3f, 3f, 5f),
        new Vector3(2.5f, 2.5f, 4.5f)};

    private readonly float[] BottleMinCapacities = {
        0.6f, 0.4f, 0.1f};
    #endregion

    [Tooltip("Game Object containing the Task class with loadable resources for current task.")]
    [SerializeField] Task task = null;

    [SerializeField] Container bottle = null;
    [SerializeField] Container glass = null;

    [Tooltip("Table boundaries used to determine correct position of grabbables on the table in respect to arms reach calibration and difficulty settings.")]
    [SerializeField] Collider tableCollider = null;

    [Tooltip("Attached to collider, triggers event when object enters the trigger collider area. Note that to work efficiently, this object should be set up under correct layer mask which interacts with grabbable objects and ignores the rest (Layer Collision Matrix in Physics Settings).")]
    [SerializeField] OnTriggerEvent drinkableAreaTrigger = null;

    [Tooltip("Position used to determine if glass pouring origin is above the mouth/eye level for tilt and drink motion. ")]
    private Transform eyeLevel = null;
    private bool bottleAboveEyeLevel = false;

    [Tooltip("Set to true if glass is held within drinkable area boundary.")]
    private bool glassInRange = false;

    [Tooltip("Set to true if bottle is held within drinkable area boundary and above user's eye level (HMD center)")]
    private bool bottleInRange = false;

    [Tooltip("Gain 1 points for every x seconds of holding bottle in drinking position.")]
    private readonly float secondsPerPoint = 5f;

    private Grabbable glassGrabbable = null;
    private float drinkingForSeconds = 0f;

    [Header("Debugging")]
    [SerializeField] bool debug = false;
    [SerializeField] TMP_Text isDrinkingLabel = null;
    [SerializeField] TMP_Text drinkingForSecondsLabel = null;
    [SerializeField] TMP_Text eyeLevelLabel = null;
    [SerializeField] TMP_Text bottleMouthLevelLabel = null;

    private void Awake()
    {
        ResizeGrabbables();
        StartCoroutine(PositionGrabbables());
        ChangeBottleCapacity();

        if(glass)
            glassGrabbable = glass.GetComponent<Grabbable>();

        if(drinkableAreaTrigger)
            eyeLevel = drinkableAreaTrigger.gameObject.transform;
    }

    private void OnEnable()
    {
        drinkableAreaTrigger.TriggerEntered += OnContainerEnterDrinkableArea;
        drinkableAreaTrigger.TriggerExited += OnContainerExitDrinkableArea;
        glass.ContainerEmpty += OnGlassEmpty;
    }

    private void OnDisable()
    {
        drinkableAreaTrigger.TriggerEntered -= OnContainerEnterDrinkableArea;
        drinkableAreaTrigger.TriggerExited -= OnContainerExitDrinkableArea;
        glass.ContainerEmpty -= OnGlassEmpty;
    }

    private void Update()
    {
        UpdateEyeAndBottleLevel();

       // Debug.LogWarning(string.Format("Liquid above pour origin: {0}", bottle.Liquid.LiquidAbovePourOrigin));

        if (glassInRange)
        {
            glass.TryPourOut();
        }
        
        if(bottleInRange && bottleAboveEyeLevel && bottle.Liquid.LiquidAbovePourOrigin)
        {
            drinkingForSeconds += Time.deltaTime;

            if (debug)
            {
                drinkingForSecondsLabel.text = drinkingForSeconds.ToString();
                if(debug) Debug.LogWarning(string.Format("Drinking for seconds: {0}", drinkingForSeconds));
            }
                

            if (drinkingForSeconds >= secondsPerPoint)
            {
                ScoreManager.Instance.IncreaseScore(task, 1);
                drinkingForSeconds = 0f;
            }
        }
    }

    // updates current eye and bottle mouth level y-coordinates and displayes the value in debug mode. 
    void UpdateEyeAndBottleLevel()
    {
        float eyeY = eyeLevel.position.y;
        float bottleY = bottle.Liquid.pourOrigin.transform.position.y;

        bottleAboveEyeLevel = eyeY <= bottleY;
        

        if (debug)
        {
            isDrinkingLabel.text = bottleAboveEyeLevel.ToString();
            eyeLevelLabel.text = eyeY.ToString();
            bottleMouthLevelLabel.text = bottleY.ToString();
        }
    }

    private void OnContainerEnterDrinkableArea(Collider collider)
    {
        if(collider.CompareTag("Glass"))
        {
            // check if user is holding the glass
            if(glassGrabbable && glassGrabbable.IsHeld)
                glassInRange = true;
        }
        else if(collider.CompareTag("Bottle"))
        {

                bottleInRange = true;
        }
    }

    private void OnContainerExitDrinkableArea(Collider collider)
    {
        if (collider.CompareTag("Glass"))
        {
            glassInRange = false;
        }
        else if (collider.CompareTag("Bottle"))
        {
            // comment out if points should only be counted for holdling bottle in correct position for 'consecutive' x-seconds.
            //drinkingForSeconds = 0f;
            bottleInRange = false;
        }
    }

    // glass only empties when held close to mouth
    private void OnGlassEmpty()
    {
        int points = 1;
        ScoreManager.Instance.IncreaseScore(task, points);
    }

    // set glass size according to difficulty level chosen
    private void ResizeGrabbables()
    {
        if (task.Settings.difficulty < 0 || (int)task.Settings.difficulty > glassSizes.Length)
            task.Settings.difficulty = 0;

        glass.transform.localScale = glassSizes[(int)task.Settings.difficulty];
    }

    // position objects at user's max reach. Depends on difficulty level set and calibration settings
    private IEnumerator PositionGrabbables()
    {
        yield return new WaitWhile(() => SettingsManager.Instance == null);

        float forwardPos = SettingsManager.Instance.Settings.maxReachForward;
        float tableSpace = tableCollider.bounds.max.x - forwardPos;

        if (task.Settings.difficulty == Difficulty.Easy)
        {
            forwardPos += tableSpace * 0.4f;
        }
        else if (task.Settings.difficulty == Difficulty.Normal)
        {
            forwardPos += tableSpace * 0.2f;
        }

        //  make sure it is within table boundary and if not, apply default values
        if (forwardPos > tableCollider.bounds.min.x && forwardPos < tableCollider.bounds.max.x)
        {
            ChangeInitialPosition(glass, forwardPos);

            // TODO fix bottle's pivot, must be remodeled in Blender. Temporarily fixed by adding offset.
            ChangeInitialPosition(bottle, forwardPos - 0.3f);
        }
        else
        {
            Debug.LogWarning("Task 1: Max reach forward outside of table boundary. Retreating to default values.");
        }
    }

    // change minimum liquid level in the bottle to enable easier pouring depending on task difficulty level. The lower the min. liquid level, the more difficult it ist to tilt bottle to pour out liquid.
    private void ChangeBottleCapacity()
    {
        bottle.minCapacity = BottleMinCapacities[(int)task.Settings.difficulty];
    }

    private void ChangeInitialPosition(Container container, float forwardPosition)
    {
        Vector3 newPosition = new Vector3(forwardPosition, container.transform.position.y, container.transform.position.z);

        container.transform.position = newPosition;

        Grabbable grabbable = container.gameObject.GetComponent<Grabbable>();

        if (grabbable)
        {
            grabbable.InitialPosition = newPosition;
        }
    }
}
