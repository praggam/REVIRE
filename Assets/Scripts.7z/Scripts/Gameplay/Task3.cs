﻿using Assets.Scripts.Gameplay;
using UnityEngine;

// Responsible for all logic related to Task 3 in which user must use both hands to grab a box from the table and place it on next podest level according to shown sequence. Sequence starts at the bottom podest level (tile), goes to the top level and switches direction, repeating until task is ended. Next tile in sequence is indicated by blue color, which changes to green on correctly positioned object is detected. 

/* Difficuly affects:
 *  - podest height (if calibration step is completed, maximum height data is adjusted to max arms reach calibration, otherwise default values are used)
 *  - (not implemented yet) box rotation - box must lay on the podest on specified side enforcing rotation movement
 */
public class Task3 : MonoBehaviour
{
    [Tooltip("Game object containing the Task class with loadable resources for current task.")]
    [SerializeField] Task task = null;

    [SerializeField]
    [Tooltip("Transform of this game object is used to adjust podest height.")]
    private GameObject podest = null;

    [SerializeField]
    [Tooltip("TODO. The box will select on which edge the box must lay to enforce object rotation.")]
    private GameObject box = null;

    [SerializeField]
    private Collider tableCollider = null;

    [Tooltip("Hard-coded podest dimensions are used if dynamic assignment not possible. This happens when no data is available from arms reach calibration.")]
    private readonly Vector3[] podestDimensions = {
        new Vector3(0.7f, 0.4f, 0.9f),
        new Vector3(0.7f, 0.5f, 0.9f),
        new Vector3(0.7f, 0.9f, 0.9f)};

    [Tooltip("Scalars for maximum podest dimension depending on difficulty setting. 1 = max podest height equal max arms reach upward")]
    private readonly float[] podestScalarsDynamic = { 0.4f, 0.6f, 0.8f };

    [SerializeField]
    private PodestLevel[] podestLevels = null;

    private int currentLevel = 0;

    private bool movingUp = true;

    private void Awake()
    {
        Debug.Assert(podestLevels.Length > 0, "No podest levels assigned");

        ResizeGrabbables();
    }

    private void Start()
    {
        foreach (PodestLevel level in podestLevels)
        {
            level.OnGrabbableEnterArea += GrabbableEnteredArea;
            level.HideDisplay();
        }

        currentLevel = podestLevels[0].level;
        DisplayNextStep();
    }

    // TODO optimization
    private void GrabbableEnteredArea(int level)
    {
        //Debug.LogWarning(string.Format("Grabbable entered podest level {0}", level));

        if (movingUp && level == currentLevel + 1)
        {
            ScoreManager.Instance.IncreaseScore(task, 1);
            podestLevels[currentLevel ].gameObject.SetActive(false);
            currentLevel = level;

            // check if reached top of podest and switch directions if so
            bool reachedTop = currentLevel == 2;//podestLevels[podestLevels.Length - 1].level;
            if (reachedTop)
            {
                movingUp = false;
            }


            DisplayNextStep();
        }
        else if (!movingUp && level == currentLevel - 1)
        {
            ScoreManager.Instance.IncreaseScore(task, 1);
            podestLevels[currentLevel].gameObject.SetActive(false);
            currentLevel = level;

            bool reachedBottom = currentLevel == 0;
            if (reachedBottom)
            {
                movingUp = true;
            }

            DisplayNextStep();
        }
    }

    // will visualize where box must be put next
    private void DisplayNextStep()
    {

        PodestLevel level = movingUp ? podestLevels[currentLevel + 1] : podestLevels[currentLevel - 1];

        if (level == null)
        {
            Debug.LogError("Task 3: Level not found.");
        }

        level.gameObject.SetActive(true);
        level.Highlight();
    }

    // set podest height according to difficulty level chosen. If user completed calibration step, use upward arms reach to define maximum podest height. Otherwise use hard-coded dimensions
    private void ResizeGrabbables()
    {
        Vector3 podestScale = podest.transform.localScale;

        if(SettingsManager.Instance.Settings.maxReachUpward != 0)
        {
            // max arms reach is defined in the world space.
            // TODO in calibration check if upward reach is taller than table height

            float up = podestScalarsDynamic[(int)task.Settings.difficulty] * (SettingsManager.Instance.Settings.maxReachUpward - tableCollider.bounds.max.y);

            podestScale = new Vector3(podestScale.x, up, podestScale.z);
        }
        else
        {
            //if (task.settings.difficulty < 0 || (int)task.settings.difficulty > podestDimensions.Length)
            //    task.settings.difficulty = 0;

            podestScale = podestDimensions[(int)task.Settings.difficulty];
        }

        podest.transform.localScale = podestScale;
    }
}