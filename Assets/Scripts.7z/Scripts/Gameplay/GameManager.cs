﻿using Assets.Scripts.Gameplay;
using System;
using System.Collections.Generic;
using UnityEngine;
using LSL;
using System.Threading;

// Responsible for all game events related to loading tasks, starting, ending, pausing and resuming session. Other classes can register to events to trigger behaviour on given event. Public methods can be accessed directly via UI to change session states.
public class GameManager : Singleton<GameManager>
{
    [Tooltip("List of all tasks in session in order of execution.")]
    [SerializeField] List<Task> tasks = new List<Task>();

    // TODO temp. This is temporarily attached to GameManager due to issue with CanvasManager event OnTaskEnd. See EndTask() method.
    [SerializeField] SummaryPanel summaryPanel = null;

    public static event Action<Task> OnTaskStarted;
    public event Action<Task> OnTaskEnded;
    public static event Action OnSessionStarted;
    public static event Action OnSessionEnded;

    [Tooltip("Assigned to currently playing task. Null if session inactive.")]
    private Task currentTask = null;

    #region PROPERTIES
    public List<Task> Tasks { get => tasks; private set => tasks = value; }
    public Task CurrentTask { get => currentTask; private set => currentTask = value; }

    StreamInfo info = new StreamInfo("TaskStart", "EEG", 8, 100, LSL.channel_format_t.cf_float32, "VR");
    StreamOutlet outlet;

    #endregion

    public bool IsLastTask() => tasks.IndexOf(currentTask) == tasks.Count - 1;
    public bool IsSessionActive() => currentTask != null;
    public void PauseSession() => Time.timeScale = 0;
    public void ResumeSession() => Time.timeScale = 1;

    private void Awake()
    {
        InitializeSingleton(this);
        TimeManager.Instance.TaskTimeEnded += EndTask;
        UIEventsManager.OnTaskMenuOpen += PauseSession;
        UIEventsManager.OnTaskMenuClose += ResumeSession;
        
        outlet = new StreamOutlet(info);
        SendLslForTask(TaskType.None);
    }

    private void OnDisable()
    {
        TimeManager.Instance.TaskTimeEnded -= EndTask;
        UIEventsManager.OnTaskMenuOpen -= PauseSession;
        UIEventsManager.OnTaskMenuClose -= ResumeSession;
    }

    public void StartSession()
    {
        OnSessionStarted?.Invoke();
        LoadNextTask();
    }

    public void EndSession()
    {
        EndTask();
        currentTask = null;
        OnSessionEnded?.Invoke();
    }

    private void StartTask(Task task)
    {
        currentTask = task;
        currentTask.Load();
        OnTaskStarted?.Invoke(currentTask);

        SendLslForTask(currentTask.Type);

        ResumeSession();
    }

    public void EndTask()
    {
        if (currentTask != null)
        {

            // TODO temp override as summary panel is updating values too late
            if (summaryPanel)
            {
                summaryPanel.OnTaskEnded(currentTask);
            }

            OnTaskEnded?.Invoke(currentTask);
            currentTask.Unload();
        }
        else
        {
            Debug.LogWarning("Game Manager: Task Ended event called while no task is active.");
        }

        PauseSession();
    }

    public void EndTask(int time)
    {
        if (currentTask != null)
        {
            currentTask.Unload();
            OnTaskEnded?.Invoke(currentTask);
        }

        PauseSession();
    }

    public void LoadNextTask()
    {
        // load first task if no task active
        if (currentTask == null)
        {
            StartTask(tasks[0]);
        }

        // end session after last task
        else if (IsLastTask())
        {
            EndSession();
        }

        // else load next task in order
        else
        {
            EndTask();
            StartTask(tasks[tasks.IndexOf(currentTask) + 1]);
        }
    }

    public void RestartCurrentTask()
    {
        if (currentTask != null)
        {
            currentTask.Restart();
            OnTaskStarted?.Invoke(currentTask);

            ResumeSession();

            SendLslForTask(currentTask.Type);
        }
        else
        {
            Debug.LogError("Error trying to restart a task: session inactive ");
        }
    }

    public void Quit()
    {
        Application.Quit();
    }


    public void SendLslForTask(TaskType taskType) 
    {
        float[] data = new float[1];
        int d = -1;

        switch (taskType)
        {
            case (TaskType.Task1): d = 1; break;
            case (TaskType.Task2): d = 2; break;
            case (TaskType.Task3): d = 3; break;
            case (TaskType.None): d = 99; break;
            default: d = 0; break;
        }
        
        for (int k = 0; k < data.Length; k++)
            data[k] = d;


        //int i = 10000;
        //while (i-- > 9950)
        //{
        //    // generate random data and send it
        //    for (int k = 0; k < data.Length; k++)
        //        data[k] = i;
        //    outlet.push_sample(data);
        //    Thread.Sleep(10);
        //}

        // create stream info and outlet
        //outlet = new StreamOutlet(info);
        outlet.push_sample(data);
                
    }

    public void SendLSLAsync(Task task)
    {
        float[] data = new float[1];
        int i = -1;

        switch (task.Type)
        {
            case (TaskType.Task1): i = 1; break;
            case (TaskType.Task2): i = 2; break;
            case (TaskType.Task3): i = 3; break;
            default: i = 0; break;
        }

        data[0] = i;

        LSLSender.Data = data;
        Thread FirstThread = new Thread(new ThreadStart(LSLSender.SendLslForTask));
        Thread SecondThread = new Thread(() => LSLSender.SendLslForTask(data));
    }

}