﻿using UnityEngine;

// Class should be attached to every canvas panel in the scene for Canvas Manager to be able to find and assign their functions. May be rewritten in the future.
public class CanvasController : MonoBehaviour
{
    public CanvasType canvasType;

    public void Hide()
    {
    }
}